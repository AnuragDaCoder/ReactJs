import { applyMiddleware, compose, createStore } from "redux";
import allReducer from "../Reducer";
import logger from "redux-logger";
import thunk from "redux-thunk";
import { composeWithDevTools } from "redux-devtools-extension";

//const composeEnhancer = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
const store = createStore(
  allReducer,
  //composeEnhancer(applyMiddleware(logger, thunk))
  composeWithDevTools(applyMiddleware(logger, thunk))
);

export default store;
