import React from "react";
import Table from "react-bootstrap/Table";

const MyWordPressPostTable = ({ myWordPressPosts }) => {
  return (
    <div>
      <h3>Some of my wordpress posts </h3>
      <Table striped bordered hover variant="dark" size="sm">
        <thead>
          <tr>
            <th width="20">Id</th>
            <th width="50">Slug</th>
            <th width="50">Link to Navigate</th>
          </tr>
        </thead>
        <tbody>
          {myWordPressPosts.items.map((data) => {
            return (
              <tr key={data.id}>
                <td>{data.id} </td>
                <td>{data.slug}</td>
                <td>
                  <a href={data.link} target="_blank">
                    {data.link}
                  </a>
                </td>
              </tr>
            );
          })}
        </tbody>
      </Table>
    </div>
  );
};
export default MyWordPressPostTable;
