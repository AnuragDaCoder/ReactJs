import axios from "axios";
import * as ActionConstant from "./ActionConstants";
export const increment = () => {
  return {
    type: ActionConstant.INCREMENT,
  };
};

export const decrement = () => {
  return {
    type: ActionConstant.DECREMENT,
  };
};

export const MultiplyBy2 = () => {
  return {
    type: ActionConstant.MULTIPLYBY2,
  };
};

export const DivideBy2 = () => {
  return {
    type: ActionConstant.DIVIDEBY2,
  };
};

// export const GetWordPressPosts = () => {
//   const response = axios.get(
//     "https://clientsidecoding.com/wp-json/wp/v2/posts"
//   );
//   return {
//     type: ActionConstant.WORDPRESSPOSTS,
//     payload: response.data,
//   };
// };

// export const GetWordPressPosts = () => {
//   return async (dispatch, getState) => {
//     const response = await axios.get(
//       "https://clientsidecoding.com/wp-json/wp/v2/posts"
//     );
//     console.log(response);
//     dispatch({
//       type: ActionConstant.WORDPRESSPOSTS,
//       payload: response.data,
//     });
//   };
// };

export const GetWordPressPosts = () => {
  return async (dispatch, getState) => {
    dispatch({
      type: ActionConstant.GET_WORDPRESSPOSTS,
    });
    try {
      const response = await axios.get(
        "https://clientsidecoding.com/wp-json/wp/v2/posts"
      );

      dispatch({
        type: ActionConstant.SUCCESS_WORDPRESSPOSTS,
        payload: response.data,
      });
    } catch (error) {
      dispatch({
        type: ActionConstant.ERROR_WORDPRESSPOSTS,
        error: error,
      });
    }
  };
};
