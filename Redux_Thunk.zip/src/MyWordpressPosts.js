import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import * as Actions from "./Actions";
import MyWordPressPostTable from "./MyWordPressPostTable";
import Spinner from "../src/Common/Spinner";

const MyWordpressPosts = () => {
  const dispatch = useDispatch();
  const myWordPressPosts = useSelector((state) => state.WordPressPosts);
  useEffect(() => {
    dispatch(Actions.GetWordPressPosts());
  }, []);

  return (
    <div>
      {myWordPressPosts.loading ? (
        <Spinner />
      ) : (
        <MyWordPressPostTable myWordPressPosts={myWordPressPosts} />
      )}
    </div>
  );
};

export default MyWordpressPosts;
