import * as ActionConstant from "../Actions/ActionConstants";
const initialState = {
  items: [],
  loading: false,
  error: null,
};

//const initialState =[];
// const wordPressPosts = (state = initialState, action) => {
//   switch (action.type) {
//     case ActionConstant.WORDPRESSPOSTS:
//       return action.payload;
//     default:
//       return state;
//   }
// };

const wordPressPosts = (state = initialState, action) => {
  switch (action.type) {
    case ActionConstant.GET_WORDPRESSPOSTS:
      return {
        ...state,
        loading: true,
        error: null,
      };
    case ActionConstant.SUCCESS_WORDPRESSPOSTS:
      return {
        ...state,
        loading: false,
        items: action.payload,
        error: null,
      };
    case ActionConstant.ERROR_WORDPRESSPOSTS:
      return {
        ...state,
        loading: false,
        error: action.error,
      };
    default:
      return state;
  }
};

export default wordPressPosts;
