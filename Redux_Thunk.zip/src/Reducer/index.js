import { combineReducers } from "redux";
import Calculator from "./Calculator";
import wordPressPosts from "./WordPressPostsReducer";

const allReducer = combineReducers({
  Calculator,
  WordPressPosts: wordPressPosts,
});

export default allReducer;
