import React, { useState } from "react";
import Display from "./Display";
import Button from "./Button";

const App = () => {
  const [counter, setCounter] = useState(0);

  const Increment = (valueBy10) => {
    console.log("clicked");
    setCounter(counter + valueBy10);
  };

  const Decrement = () => {
    console.log("clicked");
    setCounter(counter - 1);
  };

  const MultiplyByTwo = () => {
    console.log("clicked");
    setCounter(counter * 2);
  };

  const DivideBy2 = () => {
    console.log("clicked");
    setCounter(counter / 2);
  };
  return (
    <>
      <Button
        IncrementFunction={Increment}
        incrementBy10={10}
        DecrementFunction={Decrement}
        MultiplyByTwoFunction={MultiplyByTwo}
        DivideBy2Function={DivideBy2}
      />
      <Display Message={counter} />
    </>
  );
};

export default App;
