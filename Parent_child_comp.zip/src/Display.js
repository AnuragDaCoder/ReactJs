import { React } from "react";

const Display = (props) => {
  return <div>{props.Message}</div>;
};

export default Display;
