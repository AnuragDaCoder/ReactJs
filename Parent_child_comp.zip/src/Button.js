import React from "react";

const Button = (props) => {
  return (
    <div>
      <button onClick={() => props.IncrementFunction(props.incrementBy10)}>
        Increment +
      </button>
      <button onClick={props.DecrementFunction}>Decrement -</button>
      <button onClick={props.MultiplyByTwoFunction}>MultiplyByTwo * 2</button>
      <button onClick={props.DivideBy2Function}>DivideBy/2</button>
    </div>
  );
};

export default Button;
