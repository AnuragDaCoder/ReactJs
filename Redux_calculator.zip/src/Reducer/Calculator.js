import * as ActionConstant from "../Actions/ActionConstants";
const initialState = 10;

const Calculator = (state = initialState, action) => {
  switch (action.type) {
    case ActionConstant.INCREMENT:
      return state + 1;
    case ActionConstant.DECREMENT:
      return state - 1;
    case ActionConstant.MULTIPLYBY2:
      return state * 2;
    case ActionConstant.DIVIDEBY2:
      return state / 2;
    default:
      return state;
  }
};
export default Calculator;
