import React from "react";
import { useSelector, useDispatch } from "react-redux";
import * as Actions from "./Actions";

const App = () => {
  const myState = useSelector((state) => state.Calculator);
  const dispatch = useDispatch();
  return (
    <>
      <button onClick={() => dispatch(Actions.increment())}>Increment +</button>
      <button onClick={() => dispatch(Actions.decrement())}>Decrement -</button>
      <button onClick={() => dispatch(Actions.MultiplyBy2())}>
        MultiplyBy2 -
      </button>
      <button onClick={() => dispatch(Actions.DivideBy2())}>DivideBy2 -</button>
      <br /> <br />
      <span>{myState}</span>
    </>
  );
};

export default App;
