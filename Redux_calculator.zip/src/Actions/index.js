import * as ActionConstant from "./ActionConstants";
export const increment = () => {
  return {
    type: ActionConstant.INCREMENT,
  };
};

export const decrement = () => {
  return {
    type: ActionConstant.DECREMENT,
  };
};

export const MultiplyBy2 = () => {
  return {
    type: ActionConstant.MULTIPLYBY2,
  };
};

export const DivideBy2 = () => {
  return {
    type: ActionConstant.DIVIDEBY2,
  };
};
