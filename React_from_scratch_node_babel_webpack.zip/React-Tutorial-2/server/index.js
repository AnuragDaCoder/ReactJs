//var express = require("express");
import express from "express";
import { readFileSync } from "fs";

var app = express();
app.use(express.static("dist"));
app.get("/", async (req, res) => {
  const index = readFileSync(`index.html`, `utf8`);
  res.send(index);
});

var server = app.listen(8081, function () {
  var host = server.address().address;
  var port = server.address().port;
  console.log(`Example app listening at http://localhost:${port}`);
});
