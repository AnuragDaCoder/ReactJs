import React from "react";
import ReactDOM  from "react-dom";

const App = () => (
    <div>
        This is a new component !!!!!!!!!!!!!!
    </div>
  )
  
  ReactDOM.render
  (
    <div>
        <App />
        <App />
        <App />
        <App />
    </div>
  , document.getElementById("mount"));
  