import { combineReducers } from "redux";
import Calculator from "./Calculator";

const allReducer = combineReducers({
  Calculator,
});

export default allReducer;
