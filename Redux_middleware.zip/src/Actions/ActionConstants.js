export const INCREMENT = "INCREMENT";
export const DECREMENT = "DECREMENT";
export const MULTIPLYBY2 = "MULTIPLYBY2";
export const DIVIDEBY2 = "DIVIDEBY2";
