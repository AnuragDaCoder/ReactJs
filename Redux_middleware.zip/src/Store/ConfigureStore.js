import { applyMiddleware, compose, createStore } from "redux";
import allReducer from "../Reducer";
import * as ActionConstant from "../Actions/ActionConstants";
import logger from "redux-logger";

const middleware1 = (store) => (next) => (action) => {
  if (store.getState().Calculator > 5) {
    return next({ type: ActionConstant.MULTIPLYBY2 });
  }
  return next(action);
};
// const middlewar1 = (store) => {
//   return (next) => {
//     return (action) => {
//       console.log("I will be called before reducer");
//       return next(action);
//     };
//   };
// };
/*short syntax -- currying in javascript --using Arrow function*/
const composeEnhancer = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
const store = createStore(
  allReducer,
  composeEnhancer(applyMiddleware(middleware1, logger))
);

export default store;
